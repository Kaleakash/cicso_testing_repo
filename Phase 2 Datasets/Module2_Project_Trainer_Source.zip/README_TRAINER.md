# Trainer Source — Secure NetPulse Devices API

This package must contain the exact `main.py` that Claude executed, validated, and used for screenshots.

## Run
Activate the approved Phase 2 venv, set:
- `DEMO_USERNAME`
- `DEMO_PASSWORD`
- `JWT_SECRET`

Then run:
`uvicorn main:app --host 127.0.0.1 --port 8000 --reload`

Swagger:
`http://127.0.0.1:8000/docs`

Validation:
`python validate_module2_project.py`

Do not embed actual credentials or JWT signing secrets in source code.

Reviewed revision: verify JWT subject equals configured DEMO_USERNAME. Validator includes unknown-subject rejection. Historical screenshots/hashes in original guide represent the prior revision.
