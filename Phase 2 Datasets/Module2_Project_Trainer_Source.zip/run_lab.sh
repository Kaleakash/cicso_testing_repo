#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/phase2-lab
source .venv/bin/activate
cd module02-rest-services/applied-project/netpulse-devices-api
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
