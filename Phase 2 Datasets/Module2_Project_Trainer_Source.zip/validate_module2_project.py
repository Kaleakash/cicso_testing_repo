#!/usr/bin/env python3
import os, sys, httpx, jwt
from datetime import datetime, timezone

BASE = "http://127.0.0.1:8000"
USERNAME = os.getenv("DEMO_USERNAME")
PASSWORD = os.getenv("DEMO_PASSWORD")
SECRET = os.getenv("JWT_SECRET")

if not USERNAME or not PASSWORD or not SECRET:
    print("[FAIL] Required training environment variables are not set.")
    sys.exit(2)

passed = failed = 0
def check(label, ok, detail=""):
    global passed, failed
    print(f"[{'PASS' if ok else 'FAIL'}] {label} {detail}")
    passed += int(bool(ok))
    failed += int(not ok)

with httpx.Client(base_url=BASE, timeout=5.0) as client:
    r = client.get("/")
    check("Root endpoint", r.status_code == 200, f"HTTP {r.status_code}")

    r = client.get("/devices")
    check("Public GET collection", r.status_code == 200 and isinstance(r.json(), list), f"HTTP {r.status_code}")

    r = client.get("/devices/1")
    check("Public GET by id", r.status_code == 200 and r.json().get("id") == 1, f"HTTP {r.status_code}")

    r = client.get("/devices/999")
    check("Missing device -> 404", r.status_code == 404, f"HTTP {r.status_code}")

    payload = {"name":"Firewall-01","device_type":"firewall","status":"online","location":"Bangalore-DC"}

    r = client.post("/devices", json=payload)
    check("No-token POST -> 401", r.status_code == 401, f"HTTP {r.status_code}")

    r = client.post("/devices", json=payload, headers={"Authorization":"Bearer invalid.token.value"})
    check("Invalid-token POST -> 401", r.status_code == 401, f"HTTP {r.status_code}")

    r = client.post("/auth/token", data={"username":USERNAME,"password":"wrong-password"})
    check("Invalid login -> 401", r.status_code == 401, f"HTTP {r.status_code}")

    r = client.post("/auth/token", data={"username":USERNAME,"password":PASSWORD})
    token = r.json().get("access_token") if r.status_code == 200 else None
    check("Valid login -> bearer token", r.status_code == 200 and bool(token) and r.json().get("token_type")=="bearer", f"HTTP {r.status_code}")

    if token:
        claims = jwt.decode(token, SECRET, algorithms=["HS256"])
        check("JWT subject", claims.get("sub") == USERNAME, f"sub={claims.get('sub')}")
        exp = claims.get("exp")
        now = int(datetime.now(timezone.utc).timestamp())
        check("JWT expiry", isinstance(exp, int) and exp > now, f"exp={exp}")

        # A valid signature alone is insufficient: reject an unknown subject.
        foreign_token = jwt.encode(
            {"sub": "unknown-training-user", "exp": claims["exp"]},
            SECRET, algorithm="HS256"
        )
        r = client.post("/devices", json=payload, headers={"Authorization": f"Bearer {foreign_token}"})
        check("Signed token with unknown subject -> 401", r.status_code == 401, f"HTTP {r.status_code}")

        h = {"Authorization": f"Bearer {token}"}
        r = client.post("/devices", json=payload, headers=h)
        body = r.json() if r.content else {}
        created_id = body.get("id")
        check("Authenticated POST -> 201", r.status_code == 201 and created_id is not None, f"HTTP {r.status_code}, id={created_id}")

        if created_id:
            r = client.get(f"/devices/{created_id}")
            check("Read created device -> 200", r.status_code == 200, f"HTTP {r.status_code}")

            put_payload = {"name":"Firewall-Core","device_type":"firewall","status":"maintenance","location":"Bangalore-DC"}
            r = client.put(f"/devices/{created_id}", json=put_payload, headers=h)
            check("Authenticated PUT -> 200", r.status_code == 200 and r.json().get("name")=="Firewall-Core", f"HTTP {r.status_code}")

            r = client.patch(f"/devices/{created_id}", json={"status":"online"}, headers=h)
            check("Authenticated PATCH -> 200", r.status_code == 200 and r.json().get("status")=="online", f"HTTP {r.status_code}")

            r = client.delete(f"/devices/{created_id}", headers=h)
            check("Authenticated DELETE -> 204", r.status_code == 204, f"HTTP {r.status_code}")

            r = client.get(f"/devices/{created_id}")
            check("Deleted device -> 404", r.status_code == 404, f"HTTP {r.status_code}")

print(f"\nPassed: {passed}  Failed: {failed}")
print("RESULT:", "PASS" if failed == 0 else "FAIL")
sys.exit(0 if failed == 0 else 1)
