# Module 3 Section 1 — Postman Collections & Environments

This **Demo** package is separate from Practice and Solution packages. It uses the reviewed Module 2 NetPulse Devices API as its backend; Module 3 focuses on Postman.

## First run on Ubuntu / Simplilearn Sandbox

1. Extract ZIP and open `M3S1_Demo01_Source` in VS Code.
2. Open VS Code terminal. Move to `api` folder: `cd api` (from extracted root).
3. Activate the approved existing venv or create one: `python3 -m venv .venv && source .venv/bin/activate`.
4. Run `python -m pip install -r requirements.txt` **while inside `api`**.
5. Set environment variables privately in the same terminal, for example:
   ```bash
   export DEMO_USERNAME=operator
   read -rs -p 'Training password: ' DEMO_PASSWORD; echo; export DEMO_PASSWORD
   export JWT_SECRET="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
   ```
   These are local training-only credentials. Do not commit or screenshot them.
6. Run `bash run_api.sh` from `api`, and keep that terminal running.
7. Check `http://127.0.0.1:8000/` and `http://127.0.0.1:8000/docs`.

## Postman trainer flow

1. Import `postman/NetPulse_API_Module3_Section1.postman_collection.json`.
2. Import `postman/NetPulse_Local.postman_environment.json`; select **NetPulse Local**.
3. Locally set the `password` secret variable to the password used in the server terminal. Do not export it.
4. Send **Public → GET All Devices**; expect 200 and one passing basic test.
5. Send **Public → GET Device by ID**; expect 200 for device_id=1.
6. Send **Authentication → POST Login** (Body → x-www-form-urlencoded). Copy the returned access token locally and paste it into the environment's `token` variable. **Do not automate extraction here.**
7. Send **Protected → POST Create Device**; expect 201. The request includes name, device_type, status, location.
8. Clear password and token values before exporting or sharing any environment.
9. Import the separate `postman/NetPulse_Devices_OpenAPI.yaml` for comparison; this is an additional generated collection, not a replacement for the manually organized one.
10. Mock Server and Newman are **awareness only** for this section; no automation is needed.

## Troubleshooting

- `Could not open requirements file`: change into `api` before `pip install -r requirements.txt`.
- Uvicorn says missing environment variables: export them in the same terminal before running the app.
- 401 on POST: make sure you logged in successfully, copied a current JWT, and selected the proper environment.
- 422 on POST: include all four required fields, especially `location`.
- Postman cannot connect to 127.0.0.1: ensure Postman Desktop runs in the **same network environment** as the backend. If Postman runs on a different computer and FastAPI runs in a remote sandbox, `127.0.0.1` addresses different machines; use approved sandbox access/port forwarding.
- For screenshots, mask returned tokens and avoid visible credentials.
