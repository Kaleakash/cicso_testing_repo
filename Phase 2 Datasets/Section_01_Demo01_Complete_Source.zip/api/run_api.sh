#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -z "${DEMO_USERNAME:-}" || -z "${DEMO_PASSWORD:-}" || -z "${JWT_SECRET:-}" ]]; then
  echo "Set DEMO_USERNAME, DEMO_PASSWORD and JWT_SECRET in your terminal first." >&2
  exit 1
fi
exec uvicorn main:app --host 127.0.0.1 --port 8000 --reload
