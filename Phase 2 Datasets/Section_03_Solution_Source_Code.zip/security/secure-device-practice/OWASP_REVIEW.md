# OWASP API Risk Recognition

A. Any user can request another user's order by changing the order id
   → Broken Object Level Authorization

B. Normal user can call an admin-only endpoint
   → Broken Function Level Authorization

C. Expensive export endpoint has no usage limit
   → Unrestricted Resource Consumption

D. Old undocumented API version remains reachable
   → Improper Inventory Management
