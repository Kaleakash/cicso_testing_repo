# M2S3 Secure Device Creation — Solution Source

This is the **reference solution only**, not the learner Practice starter.

## Setup (Ubuntu / Simplilearn Sandbox)

From `security/secure-device-practice`:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export DEMO_USERNAME=operator
read -rsp "Training password: " DEMO_PASSWORD; echo; export DEMO_PASSWORD
export JWT_SECRET="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

The username/password/secret are temporary training values: do not publish them or capture them in screenshots. For repeatable tests, keep the environment variables set in the current terminal session.

Open http://127.0.0.1:8000/docs. Try public `GET /devices`. Protected `POST /devices` should reject no token (401). Use `POST /auth/token` with `application/x-www-form-urlencoded` username/password, or Swagger **Authorize**, to obtain a bearer token; then create a device and confirm `201`, followed by `GET /devices` showing it.

To run the included checker, activate the same environment and run from `security`:

```bash
python validate_m2s3_solution.py
```

Do not place real usernames, passwords, or JWT secrets in Git, screenshots or the document.
