# Practice Security Review

PASS — Public GET remains accessible without a token.
PASS — Protected POST rejects a missing token.
PASS — Protected POST rejects an invalid token.
PASS — Invalid login is rejected.
PASS — Valid login returns a bearer token.
PASS — Valid bearer token allows device creation.
PASS — Password is not stored as plaintext in source code.
PASS — JWT signing secret is not hardcoded in source code.
PASS — JWT includes subject and expiry claims.
PASS — HTTPS is required outside this local training lab.
PASS — Authentication does not replace authorization.
