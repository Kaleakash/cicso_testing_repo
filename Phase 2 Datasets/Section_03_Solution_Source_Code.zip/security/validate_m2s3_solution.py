#!/usr/bin/env python3
import os
import sys
from datetime import datetime, timezone

import httpx
import jwt

BASE = "http://127.0.0.1:8000"
USERNAME = os.getenv("DEMO_USERNAME")
PASSWORD = os.getenv("DEMO_PASSWORD")
SECRET = os.getenv("JWT_SECRET")

if not USERNAME or not PASSWORD or not SECRET:
    print("[FAIL] Required training environment variables are not set.")
    sys.exit(2)

passed = failed = 0

def check(label, ok, detail=""):
    global passed, failed
    if ok:
        print(f"[PASS] {label} {detail}")
        passed += 1
    else:
        print(f"[FAIL] {label} {detail}")
        failed += 1

with httpx.Client(base_url=BASE, timeout=5.0) as client:
    r = client.get("/devices")
    check("Public GET /devices", r.status_code == 200, f"HTTP {r.status_code}")

    payload = {"name":"Firewall-01","device_type":"firewall","status":"online"}

    r = client.post("/devices", json=payload)
    check("Protected POST no token -> 401", r.status_code == 401, f"HTTP {r.status_code}")

    r = client.post(
        "/devices",
        json=payload,
        headers={"Authorization":"Bearer invalid.token.value"},
    )
    check("Protected POST invalid token -> 401", r.status_code == 401, f"HTTP {r.status_code}")

    r = client.post(
        "/auth/token",
        data={"username": USERNAME, "password":"wrong-password"},
    )
    check("Invalid login -> 401", r.status_code == 401, f"HTTP {r.status_code}")

    r = client.post(
        "/auth/token",
        data={"username": USERNAME, "password": PASSWORD},
    )
    token = r.json().get("access_token") if r.status_code == 200 else None
    check(
        "Valid login -> bearer token",
        r.status_code == 200 and bool(token) and r.json().get("token_type") == "bearer",
        f"HTTP {r.status_code}",
    )

    created_id = None
    if token:
        claims = jwt.decode(token, SECRET, algorithms=["HS256"])
        check("JWT subject claim", claims.get("sub") == USERNAME, f"sub={claims.get('sub')}")
        exp = claims.get("exp")
        now = int(datetime.now(timezone.utc).timestamp())
        check("JWT expiry claim", isinstance(exp, int) and exp > now, f"exp={exp}")

        r = client.post(
            "/devices",
            json=payload,
            headers={"Authorization":f"Bearer {token}"},
        )
        body = r.json() if r.content else {}
        created_id = body.get("id")
        check(
            "Valid token POST -> 201",
            r.status_code == 201
            and created_id is not None
            and body.get("name") == "Firewall-01",
            f"HTTP {r.status_code}, id={created_id}",
        )

        r = client.get("/devices")
        body = r.json() if r.status_code == 200 else []
        visible = any(d.get("id") == created_id and d.get("name") == "Firewall-01" for d in body)
        check("Created device visible in GET", r.status_code == 200 and visible, f"HTTP {r.status_code}")

print(f"\nPassed: {passed}  Failed: {failed}")
if failed:
    print("RESULT: FAIL")
    sys.exit(1)
print("RESULT: PASS")
